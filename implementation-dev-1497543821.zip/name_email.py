name_email_dict = {
    'Nina': 'nina@calvifamily.org',
    'Theodora': 'zamfirescu.teodora@gmail.com',
    'Elizabeth': 'elisabeth.m.egger@gmail.com'
}